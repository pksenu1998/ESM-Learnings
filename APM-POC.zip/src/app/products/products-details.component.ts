import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({

  templateUrl: './products-details.component.html',
  styleUrls: ['./products-details.component.css']
})
export class ProductsDetailsComponent implements OnInit {

  pageTitle:string='Product Detail';
  constructor(private route:ActivatedRoute, private router:Router) { }

  ngOnInit(): void {
    const id=Number(this.route.snapshot.paramMap.get('id'));
  }
onBack():void
{
  this.router.navigate(['/products'])
}

}
